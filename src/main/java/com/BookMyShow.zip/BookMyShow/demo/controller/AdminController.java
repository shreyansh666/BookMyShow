package com.BookMyShow.demo.controller;

import com.BookMyShow.demo.dto.AddShowRequest;
import com.BookMyShow.demo.entities.Concert;
import com.BookMyShow.demo.entities.Movie;
import com.BookMyShow.demo.entities.Show;
import com.BookMyShow.demo.entities.Venue;
import com.BookMyShow.demo.service.AdminService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


import java.time.LocalDateTime;

@RestController
@RequestMapping("/admin")
@RequiredArgsConstructor
public class AdminController {

    @Autowired
    private final AdminService adminService;


    @PostMapping("/venue")
    public ResponseEntity<Venue> createVenue(@RequestParam String name, @RequestParam String address, @RequestParam int capacity) {
        Venue venue = adminService.createVenue(name, address, capacity);
        return ResponseEntity.ok(venue);
    }

    @PostMapping("/movie")
    public ResponseEntity<Movie> createMovieEvent(@RequestParam String venueId, @RequestParam String title, @RequestParam String genre, @RequestParam int duration, @RequestParam String description, @RequestParam LocalDateTime eventDate) {
        Movie movie = adminService.createMovieEvent(venueId, title, genre, duration, description, eventDate);
        return ResponseEntity.ok(movie);
    }

    @PostMapping("/concert")
    public ResponseEntity<Concert> createConcertEvent(@RequestParam String venueId, @RequestParam String artistName, @RequestParam String description, @RequestParam LocalDateTime eventDate) {
        Concert concert = adminService.createConcertEvent(venueId, artistName, description, eventDate);
        return ResponseEntity.ok(concert);
    }

    @PostMapping("/addShow")
    public ResponseEntity<Show> addShowToEvent(@RequestBody AddShowRequest request) {
        Show show = adminService.addShowToEvent(request);
        return ResponseEntity.ok(show);
    }
}
