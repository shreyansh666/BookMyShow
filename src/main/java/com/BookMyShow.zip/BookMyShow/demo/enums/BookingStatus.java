package com.BookMyShow.demo.enums;

public enum BookingStatus {
    BOOKED,NOT_BOOKED
}
