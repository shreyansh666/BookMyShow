package com.BookMyShow.demo.enums;

public enum UserRole {
    ADMIN,
    USER,
}