package com.BookMyShow.demo.enums;

public enum NotificationType {
    EMAIL,
    SMS,
}