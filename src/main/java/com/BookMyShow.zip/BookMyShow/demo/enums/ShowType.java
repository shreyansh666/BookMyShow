package com.BookMyShow.demo.enums;

public enum ShowType {
    MOVIE,
    STANDUP_COMEDY,
    CONCERT,
    THEATRE_PLAY
}
