package com.BookMyShow.demo.enums;

public enum SeatType {
    REGULAR,
    GOLD,
    PLATINUM,
}
