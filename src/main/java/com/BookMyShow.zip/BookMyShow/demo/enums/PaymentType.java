package com.BookMyShow.demo.enums;

public enum PaymentType {
    CASH,CARD,UPI
}
