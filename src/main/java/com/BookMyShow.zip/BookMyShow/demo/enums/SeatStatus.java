package com.BookMyShow.demo.enums;

public enum SeatStatus {
    AVAILABLE, BOOKED, MAINTENANCE
}
