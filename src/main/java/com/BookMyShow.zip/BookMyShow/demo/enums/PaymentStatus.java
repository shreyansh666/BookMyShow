package com.BookMyShow.demo.enums;

public enum PaymentStatus {
    PENDING, COMPLETED, FAILED
}
