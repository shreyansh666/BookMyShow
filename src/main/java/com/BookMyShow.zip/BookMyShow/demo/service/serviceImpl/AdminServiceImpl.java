package com.BookMyShow.demo.service.serviceImpl;

import com.BookMyShow.demo.dto.AddShowRequest;
import com.BookMyShow.demo.dto.ShowSeatConfigRequest;
import com.BookMyShow.demo.entities.*;
import com.BookMyShow.demo.enums.SeatStatus;
import com.BookMyShow.demo.enums.SeatType;
import com.BookMyShow.demo.repository.*;
import com.BookMyShow.demo.service.AdminService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class AdminServiceImpl implements AdminService {

    @Autowired
    private final VenueRepository venueRepository;
    @Autowired
    private final MovieRepository movieRepository;
    @Autowired
    private final ConcertRepository concertRepository;
    @Autowired
    private final ShowRepository showRepository;
    @Autowired
    private final SeatRepository seatRepository;

    public Venue createVenue(String name, String address, int capacity) {
        Optional<Venue> existingVenue = venueRepository.findByNameAndAddress(name, address);
        if (existingVenue.isPresent()) {
             throw new IllegalArgumentException("Venue with this name and address already exists.");
        }

        Venue venue = Venue.builder()
                .name(name)
                .address(address)
                .capacity(capacity)
                .build();
        return venueRepository.save(venue);
    }

    public Movie createMovieEvent(String venueId, String title, String genre, int duration, String description, LocalDateTime eventDate) {
        venueRepository.findById(venueId)
                .orElseThrow(() -> new RuntimeException("Venue not found"));

        Movie movie = Movie.builder()
                .title(title)
                .description(description)
                .eventDate(eventDate)
                .venueId(venueId)
                .genre(genre)
                .duration(duration)
                .build();

        return movieRepository.save(movie);
    }

    public Concert createConcertEvent(String venueId, String artistName, String description, LocalDateTime eventDate) {
        venueRepository.findById(venueId)
                .orElseThrow(() -> new RuntimeException("Venue not found"));

        Concert concert = Concert.builder()
                .artistName(artistName + " Concert")
                .description(description)
                .eventDate(eventDate)
                .venueId(venueId)
                .artistName(artistName)
                .build();

        return concertRepository.save(concert);

    }

    public Show addShowToEvent(AddShowRequest request) {
        Event event = request.isMovie() ?
                movieRepository.findById(request.getEventId()).orElseThrow(() -> new RuntimeException("Movie event not found")) :
                concertRepository.findById(request.getEventId()).orElseThrow(() -> new RuntimeException("Concert event not found"));

        List<Seat> seats = new ArrayList<>();
        ShowSeatConfigRequest config = request.getSeatConfig();


        addSeatsOfType(seats, SeatType.REGULAR, config.getRegularCount(),
                config.getRegularPrice(), request.getEventId());


        addSeatsOfType(seats, SeatType.GOLD, config.getPremiumCount(),
                config.getPremiumPrice(), request.getEventId());


        addSeatsOfType(seats, SeatType.PLATINUM, config.getVipCount(),
                config.getVipPrice(), request.getEventId());


        List<Seat> savedSeats = seatRepository.saveAll(seats);

        Show show = Show.builder()
                .title(request.getTitle())
                .description(request.getDescription())
                .duration(request.getDuration())
                .seats(savedSeats)
                .eventId(request.getEventId())
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .build();

        return showRepository.save(show);
    }


    private void addSeatsOfType(List<Seat> seats, SeatType type, int count,
                                double price, String eventId) {
        for (int i = 1; i <= count; i++) {
            String seatNumber = String.format("%s-%d-%s", type.name().charAt(0), i, eventId);
            Seat seat = Seat.builder()
                    .seatNumber(seatNumber)
                    .seatType(type)
                    .price(price)
                    .status(SeatStatus.AVAILABLE)
                    .build();
            seats.add(seat);
        }
    }
}
