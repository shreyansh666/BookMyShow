package com.BookMyShow.demo.service;


import com.BookMyShow.demo.dto.AddShowRequest;
import com.BookMyShow.demo.entities.Concert;
import com.BookMyShow.demo.entities.Movie;
import com.BookMyShow.demo.entities.Show;
import com.BookMyShow.demo.entities.Venue;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;


@Service
public interface AdminService {

    Venue createVenue(String name, String address, int capacity);

    Movie createMovieEvent(String venueId, String title, String genre, int duration, String description, LocalDateTime eventDate);

    Concert createConcertEvent(String venueId, String artistName, String description, LocalDateTime eventDate);

    Show addShowToEvent(AddShowRequest request);
}





