package com.BookMyShow.demo.dto;

import lombok.*;



@Data
@Builder
public class AddShowRequest {
    private String eventId;
    private boolean isMovie;
    private String title;
    private String description;
    private int duration;
    private ShowSeatConfigRequest seatConfig;
}
