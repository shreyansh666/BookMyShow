package com.BookMyShow.demo.dto;

public class NotificationDto {
    private String email;
    private String phone;
}
