package com.BookMyShow.demo.entities;


import lombok.*;
import lombok.experimental.SuperBuilder;
import org.springframework.data.mongodb.core.mapping.Document;


@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "concerts")

public class Concert extends Event{
    private String artistName;

}
