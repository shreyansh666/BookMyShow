package com.BookMyShow.demo.entities;



import lombok.*;
import lombok.experimental.SuperBuilder;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;


@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
@Data
@Document(collection = "movies")
public class Movie extends Event {

    private String title;
    private String genre;
    private int duration;


}
