package com.BookMyShow.demo.entities;
import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;


@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "venues")
public class Venue {
    @Id
    private String id;

    private String name;
    private String address;
    private int capacity;

//    @JsonBackReference
//    @Builder.Default
//    @DBRef
//    private List<Event> event = new ArrayList<>();





}
