package com.BookMyShow.demo.entities;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import lombok.*;
import lombok.experimental.SuperBuilder;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDateTime;
import java.util.List;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "events")
public abstract class Event {

    @Id
    private String id;

    private String name;
    private String description;
    private LocalDateTime eventDate;

//    @JsonManagedReference
//    @DBRef
//    private Venue venue;

    private String venueId;

//    @DBRef
    private List<String> showsIds;

}