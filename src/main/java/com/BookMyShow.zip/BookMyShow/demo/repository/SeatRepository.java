package com.BookMyShow.demo.repository;

import com.BookMyShow.demo.entities.Payment;
import com.BookMyShow.demo.entities.Seat;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface SeatRepository extends MongoRepository<Seat, String> {

    Optional<Seat> findById(String Id);
}
