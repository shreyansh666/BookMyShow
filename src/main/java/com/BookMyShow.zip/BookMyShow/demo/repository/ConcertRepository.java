package com.BookMyShow.demo.repository;

import com.BookMyShow.demo.entities.Concert;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ConcertRepository extends MongoRepository<Concert, String> {

    List<Concert> findByArtistNameContainingIgnoreCase(String artistName);
}

