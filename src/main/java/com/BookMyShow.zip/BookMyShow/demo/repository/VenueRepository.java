package com.BookMyShow.demo.repository;

import com.BookMyShow.demo.entities.Venue;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import javax.swing.text.html.Option;
import java.util.Optional;

@Repository
public interface VenueRepository extends MongoRepository<Venue, String> {

    Venue findByName(String name);
    Optional<Venue> findByNameAndAddress(String name, String address);
}

